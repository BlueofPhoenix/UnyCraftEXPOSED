<div class="navbar">
    <nav>
        <a href="../index.php">Mein Stundenplan</a>
        <ul>
            <a href="../index.php">HOME</a>
            <li><a href="../4C4F4C/seite1.php">Lustige-Seite-1</a></li>
            <li><a href="https://www.microsoft365.com/launch/word?auth=2">OFFICE</a></li>
            <li><a href="https://cloud.theunycraft.tech/">UnyCloud</a></li>
        </ul>
    </nav>
</div>